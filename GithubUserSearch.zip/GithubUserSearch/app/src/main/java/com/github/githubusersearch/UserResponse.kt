package com.github.githubusersearch

data class UserResponse(
    val items : ArrayList<User>
)
